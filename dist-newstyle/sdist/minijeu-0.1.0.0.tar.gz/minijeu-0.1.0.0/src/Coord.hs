module Coord
    where

import Data.Sequence (Seq, Seq (..))
import qualified Data.Sequence as Seq

import Data.Set (Set)
import qualified Data.Set as Set


data Zone = Zone Integer Integer 
    deriving Show
data Coord = Coord Integer Integer 
    deriving (Show,Eq)

data Direction = H | B | G | D deriving (Show,Eq)
data Mouvement = Mouv Direction Integer 
    deriving Show

--instance (Num a, Ord a) => Eq (Coord a a) where
--    (==) (Coord x1 y1) (Coord x2 y2) = x1==x2 && y1==y2


bougeCoord :: Coord -> Mouvement -> Coord
bougeCoord (Coord x y) (Mouv H v) = (Coord x (y+v))
bougeCoord (Coord x y) (Mouv B v) = (Coord x (y-v))
bougeCoord (Coord x y) (Mouv G v) = (Coord (x-v) y)
bougeCoord (Coord x y) (Mouv D v) = (Coord (x+v) y)

--bougeCoordSafe ( (Coord 5 3), (Mouv G 10), (Zone 30 30))


bougeCoordSafe :: Coord -> Mouvement -> Zone -> Maybe Coord
bougeCoordSafe c m (Zone h l) = let ( Coord x y) = (bougeCoord c m) in 
    if y>=0 && y<=h && x>=(-l) && x<=l then Just (Coord x y)
    else Nothing

prop_gaucheDroite_bougeCoord :: Coord -> Integer -> Bool 
prop_gaucheDroite_bougeCoord c v = bougeCoord (bougeCoord c (Mouv G v)) (Mouv D v)  == c

-- >>> prop_gaucheDroite_bougeCoord (Coord 5 3) 6

