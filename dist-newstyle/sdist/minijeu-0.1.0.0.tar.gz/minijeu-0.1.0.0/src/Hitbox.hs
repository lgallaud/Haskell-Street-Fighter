module Hitbox 
    where

import Coord

import Data.Sequence (Seq, Seq (..))
import qualified Data.Sequence as Seq

import Data.Set (Set)
import qualified Data.Set as Set



data Hitbox = Rect Coord Integer Integer 
            | Composite (Seq Hitbox) 
            deriving Show

prop_Inv_Hitbox :: Hitbox -> Bool
prop_Inv_Hitbox (Composite s) = null s 
prop_Inv_Hitbox _ = True

makeRect :: Coord -> Coord -> Hitbox
makeRect (Coord x1 y1) (Coord x2 y2)  = ( Rect (Coord (min x1 x2) (min y1 y2)) (abs $ x1-x2) (abs $ y1-y2))

construireHitbox :: Seq (Coord, Coord) -> Hitbox
construireHitbox (( c1, c2 ) :<| Empty) = makeRect c1 c2
construireHitbox (( c1, c2 ) :<| cx) = (Composite ( (makeRect c1 c2):<|(aux cx) ))

aux :: Seq (Coord, Coord) -> Seq Hitbox
aux (( c1, c2 ) :<| Empty) = (makeRect c1 c2):<|Empty
aux (( c1, c2 ) :<| cx) = (makeRect c1 c2):<|(aux cx) 

c1= Coord 3 8
c2 = Coord 1 4
c3 = Coord 25 8
c4 = Coord 8 3 
test = Seq.fromList [(c1,c2),(c3,c4)]


-- >>> construireHitbox test
-- Composite (fromList [Rect (Coord 1 4) 2 4,Rect (Coord 8 3) 17 5])
--

-- >>> construireHitbox (Seq.fromList [(c1,c2)])
-- Rect (Coord 1 4) 2 4
--


--if (Coord x1 y1)==(Coord x2 y2) 
--    then Nothing 
--    else Just


appartient :: Coord -> Hitbox -> Bool
appartient ( Coord x y ) (Rect (Coord xr yr) h l) = x>xr && x<(xr+l) && y>yr && y<(yr+h)
appartient c (Composite Empty ) = False
appartient c (Composite (r:<|rs) ) = if appartient c r then True else appartient c (Composite rs)


-- >>>appartient (Coord 80 80) (Rect (Coord 30 30) 100 100 )
-- True
--

box1= construireHitbox test

bougeHitbox :: Hitbox -> Mouvement -> Hitbox
bougeHitbox (Rect c h l ) m = (Rect (bougeCoord c m ) h l)
bougeHitbox (Composite (r:<|rs)) m = Composite ((bougeHitbox r m):<| bougeAux rs m)

bougeAux :: Seq Hitbox -> Mouvement -> Seq Hitbox
bougeAux (r:<|rs) m = (bougeHitbox r m):<|(bougeAux rs m)
bougeAux (Empty) m = Empty

-- >>> bougeHitbox box1 (Mouv H 2)
-- Composite (fromList [Rect (Coord 1 6) 2 4,Rect (Coord 8 5) 17 5])
--


--prop_post_bougeHitbox :: HitBox -> Mouvement -> Bool
--prop_post_bougeHitbox 


--Ne fonctionne pas totalement 
bougeHitboxSafe :: Hitbox -> Mouvement -> Zone -> Maybe Hitbox
bougeHitboxSafe (Rect c h l) m z = case bougeCoordSafe c m z of
   Nothing -> Nothing
   Just hi -> Just (Rect (bougeCoord c m) h l)
bougeHitboxSafe (Composite (r:<|rs)) m z = case bougeHitboxSafe r m z of
    Nothing -> Nothing
    Just r -> if bougeAuxSafe rs m z then Just (Composite ((bougeHitbox r m):<| (bougeAux rs m)))
    else Nothing

bougeAuxSafe :: Seq Hitbox -> Mouvement -> Zone -> Bool 
bougeAuxSafe (r:<|rs) m z = case  bougeHitboxSafe r m z of
    Nothing -> False
    Just r -> True && bougeAuxSafe rs m z 
bougeAuxSafe Empty m z = True

-- >>> bougeHitboxSafe box1 (Mouv H 2)
-- <interactive>:12011:2-32: error:
--     • No instance for (Show (Zone -> Maybe Hitbox))
--         arising from a use of ‘print’
--         (maybe you haven't applied a function to enough arguments?)
--     • In a stmt of an interactive GHCi command: print it
--


--INCOMPLET
collision :: Hitbox -> Hitbox -> Bool
collision (Rect (Coord x1 y1) h1 l1) (Rect (Coord x2 y2) h2 l2) = 
    appartient (Coord x1 y1) (Rect (Coord x2 y2) h2 l2) ||
    appartient (Coord (x1+l1) y1) (Rect (Coord x2 y2) h2 l2) ||
    appartient (Coord x1 (y1+h1)) (Rect (Coord x2 y2) h2 l2) ||
    appartient (Coord (x1+l1) (y1+h1)) (Rect (Coord x2 y2) h2 l2) ||
    
    appartient (Coord x2 y2) (Rect (Coord x1 y1) h1 l1) ||
    appartient (Coord (x2+l2) y2) (Rect (Coord x1 y1) h1 l1) ||
    appartient (Coord x2 (y2+h2)) (Rect (Coord x1 y1) h1 l1) ||
    appartient (Coord (x2+l2) (y2+h2)) (Rect (Coord x1 y1) h1 l1) 
--collision (Rect (Coord x1 y1) h1 l1) hit = 
--    fmap ( (||) collision (Rect (Coord x1 y1) h1 l1)  ) false hit  



-- >>> collision (Rect (Coord 30 30) 100 100 ) (Rect (Coord 20 20) 100 0 )
-- False
--

