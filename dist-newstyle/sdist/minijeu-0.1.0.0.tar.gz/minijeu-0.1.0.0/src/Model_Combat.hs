module Model_Combat
     where

import Data.Sequence (Seq, Seq (..))
import qualified Data.Sequence as Seq

import Data.Set (Set)
import qualified Data.Set as Set
import Coord
import Hitbox
import SDL

import Keyboard (Keyboard)
import qualified Keyboard as K

data EtatCombattant = Ko | Ok Integer deriving Show

data Combattant = Comb {
    positionc :: Coord,
    hitboxc :: Hitbox,
    facec :: Direction,
    etatx :: EtatCombattant
} deriving Show

data Jeu = GameOver Integer
        | EnCours {
            joueur1 :: Combattant,
            joueur2 :: Combattant,
            zoneJeu :: Zone
        }
        deriving Show

getCombX :: Combattant -> Integer
getCombX (Comb (Coord x y) _ _ _) = x

getCombY :: Combattant -> Integer
getCombY (Comb (Coord x y) _ _ _) = y

inZone :: Coord -> Zone -> Bool
inZone (Coord x y ) (Zone h l ) = y>=0 && y<=h && x>=(-l) && x<=l

prop_inv_Position :: Jeu -> Bool
prop_inv_Position (GameOver i) = True
prop_inv_Position (EnCours (Comb p1 _ _ _) (Comb p2 _ _ _) z) = inZone p1 z && inZone p2 z

j1= ( Comb (Coord 2 3) box1 G (Ok 0) )
j2= ( Comb (Coord 3 4) box1 G (Ok 3) )

-- >>> prop_inv_Position (GameOver 2)
-- True
--

-- >>> prop_inv_Position (EnCours j1 j2 (Zone 20 20))
-- True
--

prop_inv_Chevauchement :: Jeu -> Bool
prop_inv_Chevauchement (GameOver i) = True
prop_inv_Chevauchement (EnCours (Comb _ h1 _ _) (Comb _ h2 _ _) _) = not(collision h1 h2)

prop_inv_Face :: Jeu -> Bool
prop_inv_Face (GameOver i) = True
prop_inv_Face (EnCours (Comb _ _ d1 _) (Comb _ _ d2 _) _) = (d1 == G && d2 == D) || (d1==D && d2==G)


tourJeu :: Jeu -> Jeu
tourJeu _ = undefined

prop_post_tourJeu :: Jeu -> Bool
prop_post_tourJeu (GameOver i) = True
prop_post_tourJeu j@(EnCours c1 c2 _) = aux_prop_post_tourJeu c1 j  && aux_prop_post_tourJeu c2 j 


aux_prop_post_tourJeu :: Combattant -> Jeu -> Bool
aux_prop_post_tourJeu (Comb _ _ _ e) j  = case e of
    Ko -> case tourJeu j of
        GameOver _ -> True
        _ -> False
    Ok i -> if i <=0 then case tourJeu j of
        GameOver _ -> True
        _ -> False
         else True 


-- >>> prop_post_tourJeu (EnCours j1 j2 (Zone 20 20))
-- False
--

bougeJoueur :: Integer -> Jeu -> Mouvement -> Jeu
bougeJoueur i j@(EnCours c1@(Comb p1 h1 _ _) c2@(Comb p2 h2 _ _) z ) m@(Mouv d _)
    | i==1 = if (auxbougeJoueur c1 c2 z m) then (EnCours c1{positionc = (bougeCoord p1 m), hitboxc=(bougeHitbox h1 m), facec=d} c2 z) else j
    | i==2 = if (auxbougeJoueur c2 c1 z m )then (EnCours c1 c2{positionc = (bougeCoord p2 m), hitboxc=(bougeHitbox h2 m), facec=d}  z) else j 
    | otherwise = j

auxbougeJoueur :: Combattant -> Combattant -> Zone -> Mouvement -> Bool
auxbougeJoueur (Comb p1 h1 _ _) (Comb _ h2 _ _) z m = 
    case (bougeCoordSafe p1 m z) of
        Nothing -> False
        Just (Coord x y) -> True && (collision (bougeHitbox h1 m) h2)

-- >>> bougeJoueur 2 initJeu (Mouv G 4)
-- EnCours {joueur1 = Comb {positionc = Coord 200 300, hitboxc = Rect (Coord 200 300) 1 1, facec = D, etatx = Ok 5}, joueur2 = Comb {positionc = Coord 396 300, hitboxc = Rect (Coord 396 300) 1 1, facec = G, etatx = Ok 5}, zoneJeu = Zone 640 480}
--

-- >>> initJeu
-- EnCours {joueur1 = Comb {positionc = Coord 200 300, hitboxc = Rect (Coord 200 300) 1 1, facec = D, etatx = Ok 5}, joueur2 = Comb {positionc = Coord 400 300, hitboxc = Rect (Coord 400 300) 1 1, facec = G, etatx = Ok 5}, zoneJeu = Zone 640 480}
--

initCombattant1 :: Combattant
initCombattant1 = Comb (Coord 200 300) (Rect (Coord 200 300) 1 1) D (Ok 5)

initCombattant2 :: Combattant
initCombattant2 = Comb (Coord 400 300) (Rect (Coord 400 300) 1 1) G (Ok 5)

initJeu :: Jeu
initJeu = (EnCours initCombattant1 initCombattant2 (Zone 640 480))

--clicValide :: Maybe (V2 Int) -> Jeu -> Bool
--clicValide coord gs@(GameState px py _) =
--  case coord of
--    Just (V2 x y) -> px <= x && x <= (px+100) && py <= y && y <= (py+100)
--    Nothing -> False

moveLeft :: Integer -> Jeu -> Jeu
moveLeft i j = bougeJoueur i j (Mouv G 1)

moveRight :: Integer-> Jeu -> Jeu
moveRight i j = bougeJoueur i j (Mouv D 1)
                              
moveUp :: Integer -> Jeu -> Jeu
moveUp i j = bougeJoueur i j (Mouv B 1)

moveDown :: Integer -> Jeu -> Jeu
moveDown i j = bougeJoueur i j (Mouv H 1)


gameStep :: RealFrac a => Jeu -> Keyboard -> a -> Jeu
gameStep jeu kbd deltaTime =
  let modif = (if K.keypressed KeycodeLeft kbd
               then moveLeft 2 else id)
              .
              (if K.keypressed KeycodeRight kbd
               then moveRight 2 else id)
              .
              (if K.keypressed KeycodeUp kbd
               then moveUp 2 else id)
              .
              (if K.keypressed KeycodeDown kbd
               then moveDown 2 else id)
               .
                (if K.keypressed KeycodeQ kbd
               then moveLeft 1 else id)
              .
              (if K.keypressed KeycodeD kbd
               then moveRight 1 else id)
              .
              (if K.keypressed KeycodeZ kbd
               then moveUp 1 else id)
              .
              (if K.keypressed KeycodeS kbd
               then moveDown 1 else id)
              
  in modif jeu

